Elevator driver for Go
======================

See [`main.go`](main.go) for usage example. The code is runnable with just `go run main.go`

---

Add these lines to your `go.mod` file:
```
require Driver-go v0.0.0
replace Driver-go => ./Driver-go
```
Where `./Driver-go` is the relative path to this folder, after you have downloaded it.









